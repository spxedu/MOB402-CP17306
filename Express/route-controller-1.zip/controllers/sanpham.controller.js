exports.getList = (req, res, next)=>{

    res.render('sanpham/list');
}

exports.addProduct = (req, res, next)=>{

    res.render('sanpham/add');
}