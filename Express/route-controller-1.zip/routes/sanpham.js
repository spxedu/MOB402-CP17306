var express = require('express');
var router = express.Router(); 
var spController = require('../controllers/sanpham.controller');

// trang danh sách 
router.get('/', spController.getList );

router.get('/add', spController.addProduct );



// cần có export
module.exports = router;